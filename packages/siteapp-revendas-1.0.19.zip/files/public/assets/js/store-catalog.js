(function () {
  'use strict';

  var modal = document.getElementById('download-modal');
  if (!modal) return;

  var title = modal.querySelector('[data-modal-title]');
  var codes = modal.querySelector('[data-modal-codes]');
  var share = modal.querySelector('[data-modal-share]');
  var closeButtons = modal.querySelectorAll('[data-modal-close]');
  var currentShare = { title: '', url: '' };

  function closeModal() {
    modal.hidden = true;
    document.body.classList.remove('modal-open');
  }

  function openModal(button) {
    var payload;
    try {
      payload = JSON.parse(button.getAttribute('data-download') || '{}');
    } catch (error) {
      payload = {};
    }

    title.textContent = payload.name || 'Aplicativo';
    currentShare.title = payload.name || document.title;
    currentShare.url = new URL(payload.url || window.location.href, window.location.origin).href;
    codes.innerHTML = '';

    (payload.codes || []).forEach(function (item) {
      var row = document.createElement('div');
      row.className = 'download-code-row';

      var label = document.createElement('label');
      label.textContent = item.type === 'NTDOWN' ? 'Código NTDown' : 'Código Downloader';

      var field = document.createElement('div');
      field.className = 'download-code-field';

      var value = document.createElement('span');
      value.textContent = item.code || '';

      var copy = document.createElement('button');
      copy.type = 'button';
      copy.className = 'copy-code';
      copy.setAttribute('aria-label', 'Copiar ' + label.textContent);
      copy.innerHTML = '<span aria-hidden="true">▣</span>';
      copy.addEventListener('click', function () {
        navigator.clipboard.writeText(item.code || '').then(function () {
          copy.classList.add('copied');
          copy.innerHTML = '<span aria-hidden="true">✓</span>';
          setTimeout(function () {
            copy.classList.remove('copied');
            copy.innerHTML = '<span aria-hidden="true">▣</span>';
          }, 1400);
        });
      });

      field.append(value, copy);
      row.append(label, field);
      codes.append(row);
    });

    if (payload.download) {
      var direct = document.createElement('a');
      direct.className = 'download-direct-link';
      direct.href = payload.download;
      direct.target = '_blank';
      direct.rel = 'noopener';
      direct.textContent = 'Baixar arquivo diretamente';
      codes.append(direct);
    }

    modal.hidden = false;
    document.body.classList.add('modal-open');
    modal.querySelector('.download-modal-close').focus();
  }

  document.querySelectorAll('[data-open-download]').forEach(function (button) {
    button.addEventListener('click', function () {
      openModal(button);
    });
  });

  closeButtons.forEach(function (button) {
    button.addEventListener('click', closeModal);
  });

  modal.addEventListener('click', function (event) {
    if (event.target === modal) closeModal();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && !modal.hidden) closeModal();
  });

  document.querySelectorAll('[data-share-app]').forEach(function (button) {
    button.addEventListener('click', function () {
      var shareData = {
        title: button.getAttribute('data-share-title') || document.title,
        url: new URL(button.getAttribute('data-share-url') || window.location.href, window.location.origin).href
      };
      if (navigator.share) {
        navigator.share(shareData).catch(function () {});
      } else {
        navigator.clipboard.writeText(shareData.url);
      }
    });
  });

  share.addEventListener('click', function () {
    if (navigator.share) {
      navigator.share(currentShare).catch(function () {});
    } else {
      navigator.clipboard.writeText(currentShare.url);
    }
  });
}());


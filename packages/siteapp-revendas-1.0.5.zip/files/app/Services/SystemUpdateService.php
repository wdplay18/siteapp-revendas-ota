<?php

declare(strict_types=1);

namespace SiteApp\Services;

use RuntimeException;
use ZipArchive;

final class SystemUpdateService
{
    private const PROTECTED_PREFIXES = ['config/','storage/uploads/','storage/backups/','storage/deletion-staging/'];
    private const PROTECTED_FILES = ['config/config.php'];
    private const MAX_REMOTE_PACKAGE = 104857600;
    private const OTA_PUBLIC_KEY = <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAk1RMFu/+mp9u9Q2ndmWx
U3WDeKRMFtKwvDfZR2GkVRf23P4evrweeBYV6wCR2DcxsT2gVUS0R9fLzyZBKKNs
vbPV4glY0s7FhDoCO67CJRDgHBQBSBB0rT+WdZCpiTWTlYGsLb+JbqDPYnAz0rGx
d1dnmnVhStGyltQcJeQ3w1YnBXdeAcCKBZ8eICKQZRf5JpAazJVHCYgCH5xzOYRM
vCBOBNbdEETxnpdTLSTVgbYvUTo+YknFD5aRYH4If8t98OW82htl8N0uOWterIgG
y2hvkxm+4j/68rgtt2ezFu9mObBQWAtH8WAYBzSnv4DqxKlkYM/p+UpmGWJDhIJI
vp4NHsmPViFOCBatv3LBjqv3QAALHxgknbOAXjUsq3wqZbXFbp2d+DsKDguaVSPU
sSMhr1RHGGc6V5hLVo5U0rucpBrZuPGbTuguGp1hFWKuHnWVHMzYk+b/U8tybWym
115RsURqOFWLM9o3jUZC3p/Q/H4Lu9u6IhpjJfGKd1YzAgMBAAE=
-----END PUBLIC KEY-----
PEM;

    public function __construct(private string $root) {}

    public function currentVersion(): string
    {
        $file=$this->root.'/VERSION';
        return is_file($file)?trim((string)file_get_contents($file)):'1.0.0';
    }

    public function remoteStatus(array $config): array
    {
        $url=trim((string)($config['updates']['manifest_url']??''));
        if($url==='')return ['configured'=>false,'current'=>$this->currentVersion()];
        $manifest=$this->fetchJson($this->httpsUrl($url,'manifesto'));
        $this->verifyManifestSignature($manifest);
        $version=trim((string)($manifest['version']??''));
        $packageUrl=trim((string)($manifest['package_url']??''));
        $sha=strtolower(trim((string)($manifest['sha256']??'')));
        if($version===''||$packageUrl===''||!preg_match('/^[a-f0-9]{64}$/',$sha))throw new RuntimeException('O canal OTA retornou um manifesto inválido.');
        $this->httpsUrl($packageUrl,'pacote');
        $current=$this->currentVersion();
        return ['configured'=>true,'current'=>$current,'version'=>$version,'available'=>version_compare($version,$current,'>'),'package_url'=>$packageUrl,'sha256'=>$sha,'changelog'=>is_array($manifest['changelog']??null)?array_values(array_filter(array_map('strval',$manifest['changelog']))):[],'signed'=>true];
    }

    public function installRemote(array $config): array
    {
        $status=$this->remoteStatus($config);
        if(!($status['configured']??false))throw new RuntimeException('O canal OTA ainda não foi configurado.');
        if(!($status['available']??false))throw new RuntimeException('Não há atualização nova disponível.');
        $tmpDir=$this->root.'/storage/tmp';$this->mkdir($tmpDir);$tmp=$tmpDir.'/ota-'.bin2hex(random_bytes(8)).'.zip';
        try{
            $this->download((string)$status['package_url'],$tmp);
            $actual=hash_file('sha256',$tmp);
            if(!is_string($actual)||!hash_equals((string)$status['sha256'],strtolower($actual)))throw new RuntimeException('O pacote OTA falhou na validação SHA-256.');
            $result=$this->installUploadedPackage($tmp);
            if(!hash_equals((string)$status['version'],(string)$result['version']))throw new RuntimeException('A versão instalada não corresponde ao manifesto OTA.');
            return $result;
        }finally{if(is_file($tmp))@unlink($tmp);}
    }

    public function installUploadedPackage(string $zipPath): array
    {
        if(!class_exists(ZipArchive::class))throw new RuntimeException('A extensão ZIP não está disponível no servidor.');
        if(!is_file($zipPath))throw new RuntimeException('Pacote de atualização não encontrado.');
        $zip=new ZipArchive();if($zip->open($zipPath)!==true)throw new RuntimeException('Não foi possível abrir o pacote de atualização.');
        try{
            $raw=$zip->getFromName('update.json');if($raw===false)throw new RuntimeException('Pacote inválido: update.json ausente.');
            $manifest=json_decode($raw,true,512,JSON_THROW_ON_ERROR);$version=trim((string)($manifest['version']??''));$files=$manifest['files']??null;
            if($version===''||!is_array($files)||!$files)throw new RuntimeException('Manifesto de atualização inválido.');
            if(version_compare($version,$this->currentVersion(),'<=') )throw new RuntimeException('O pacote precisa ter versão superior à instalada.');
            $staging=$this->root.'/storage/tmp/update-'.bin2hex(random_bytes(8));$rollback=$this->root.'/storage/backups/update-rollback-'.date('Ymd-His').'-'.bin2hex(random_bytes(4));
            $this->mkdir($staging);$this->mkdir($rollback);$prepared=[];
            foreach($files as$item){if(!is_array($item))throw new RuntimeException('Entrada de arquivo inválida no manifesto.');$path=$this->safePath((string)($item['path']??''));$hash=strtolower((string)($item['sha256']??''));if(!preg_match('/^[a-f0-9]{64}$/',$hash))throw new RuntimeException('SHA-256 inválido para '.$path);$this->assertWritablePath($path);$entry='files/'.$path;$data=$zip->getFromName($entry);if($data===false)throw new RuntimeException('Arquivo ausente no pacote: '.$path);if(!hash_equals($hash,hash('sha256',$data)))throw new RuntimeException('Integridade inválida: '.$path);$tmp=$staging.'/'.$path;$this->mkdir(dirname($tmp));if(file_put_contents($tmp,$data)===false)throw new RuntimeException('Falha ao preparar '.$path);$prepared[]=$path;}
            $changed=[];
            try{foreach($prepared as$path){$target=$this->root.'/'.$path;$source=$staging.'/'.$path;if(is_file($target)){$backup=$rollback.'/'.$path;$this->mkdir(dirname($backup));if(!copy($target,$backup))throw new RuntimeException('Falha ao proteger '.$path);}$this->mkdir(dirname($target));if(!copy($source,$target))throw new RuntimeException('Falha ao instalar '.$path);$changed[]=$path;}if(file_put_contents($this->root.'/VERSION',$version."\n")===false)throw new RuntimeException('Falha ao registrar a nova versão.');}
            catch(\Throwable$e){foreach(array_reverse($changed)as$path){$backup=$rollback.'/'.$path;$target=$this->root.'/'.$path;if(is_file($backup))@copy($backup,$target);else@unlink($target);}throw $e;}
            $this->removeTree($staging);return['version'=>$version,'files'=>count($prepared),'rollback'=>basename($rollback)];
        }finally{$zip->close();}
    }

    private function verifyManifestSignature(array $manifest): void
    {
        if(!function_exists('openssl_verify'))throw new RuntimeException('A extensão OpenSSL é necessária para validar a assinatura OTA.');
        $signature=base64_decode((string)($manifest['signature']??''),true);
        if($signature===false||$signature==='')throw new RuntimeException('O manifesto OTA não possui uma assinatura digital válida.');
        $payload=json_encode([
            'version'=>(string)($manifest['version']??''),
            'package_url'=>(string)($manifest['package_url']??''),
            'sha256'=>strtolower((string)($manifest['sha256']??'')),
            'changelog'=>is_array($manifest['changelog']??null)?array_values(array_map('strval',$manifest['changelog'])):[],
        ],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        if(!is_string($payload)||openssl_verify($payload,$signature,self::OTA_PUBLIC_KEY,OPENSSL_ALGO_SHA256)!==1)throw new RuntimeException('Assinatura digital do manifesto OTA inválida. Atualização bloqueada.');
    }

    private function fetchJson(string $url): array
    {
        $raw=$this->request($url,1048576);try{$data=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(\Throwable){throw new RuntimeException('O manifesto OTA não contém JSON válido.');}if(!is_array($data))throw new RuntimeException('Manifesto OTA inválido.');return$data;
    }

    private function download(string $url,string $target): void
    {
        $data=$this->request($this->httpsUrl($url,'pacote'),self::MAX_REMOTE_PACKAGE);if(file_put_contents($target,$data,LOCK_EX)===false)throw new RuntimeException('Não foi possível salvar o pacote OTA temporário.');
    }

    private function request(string $url,int $max): string
    {
        $context=stream_context_create(['http'=>['method'=>'GET','timeout'=>20,'follow_location'=>0,'ignore_errors'=>false,'header'=>"User-Agent: SiteApp-Updater/2\r\nAccept: application/json, application/zip;q=0.9, */*;q=0.1\r\n"],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $stream=@fopen($url,'rb',false,$context);if($stream===false)throw new RuntimeException('Não foi possível acessar o canal OTA por HTTPS.');$data='';try{while(!feof($stream)){$chunk=fread($stream,1048576);if($chunk===false)throw new RuntimeException('Falha ao baixar dados do canal OTA.');$data.=$chunk;if(strlen($data)>$max)throw new RuntimeException('O arquivo remoto excede o limite permitido.');}}finally{fclose($stream);}return$data;
    }

    private function httpsUrl(string $url,string $label): string
    {
        if(!filter_var($url,FILTER_VALIDATE_URL)||strtolower((string)parse_url($url,PHP_URL_SCHEME))!=='https')throw new RuntimeException('URL HTTPS inválida para '.$label.' OTA.');$host=strtolower((string)parse_url($url,PHP_URL_HOST));if($host===''||$host==='localhost'||filter_var($host,FILTER_VALIDATE_IP))throw new RuntimeException('Host OTA inválido.');return$url;
    }

    private function safePath(string $path): string
    {
        $path=str_replace('\\','/',$path);if($path===''||str_starts_with($path,'/')||str_contains($path,"\0"))throw new RuntimeException('Caminho inválido no pacote.');foreach(explode('/',$path)as$p)if($p===''||$p==='.'||$p==='..')throw new RuntimeException('Caminho inválido no pacote.');return$path;
    }
    private function assertWritablePath(string $path): void
    {
        if(in_array($path,self::PROTECTED_FILES,true))throw new RuntimeException('O pacote tentou alterar um arquivo protegido.');foreach(self::PROTECTED_PREFIXES as$p)if(str_starts_with($path,$p))throw new RuntimeException('O pacote tentou alterar dados protegidos: '.$path);
    }
    private function mkdir(string $dir): void{if(!is_dir($dir)&&!mkdir($dir,0775,true)&&!is_dir($dir))throw new RuntimeException('Não foi possível preparar a pasta de atualização.');}
    private function removeTree(string $dir): void{if(!is_dir($dir))return;foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST)as$item){$item->isDir()?@rmdir($item->getPathname()):@unlink($item->getPathname());}@rmdir($dir);}
}

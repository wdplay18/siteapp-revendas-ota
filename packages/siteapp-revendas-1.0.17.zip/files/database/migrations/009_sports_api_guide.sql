-- SiteApp Revendas - migration 009
-- Guia de Jogos alimentado por APIs JSON globais configuradas pelo Master.
CREATE TABLE IF NOT EXISTS sports_api_settings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 sport ENUM('football','basketball','ufc') NOT NULL,
 api_url VARCHAR(1000) NOT NULL,
 tomorrow_url VARCHAR(1000) NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_sports_api_sport(sport)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

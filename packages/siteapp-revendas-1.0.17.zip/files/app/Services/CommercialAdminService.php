<?php

declare(strict_types=1);

namespace SiteApp\Services;

use PDO;
use RuntimeException;

final class CommercialAdminService
{
    public function __construct(private PDO $pdo) {}

    private function scope(array $tenant): array
    {
        $type=(string)($tenant['type']??'');
        if($type==='master')return ['master',null];
        if($type==='reseller'){
            $rid=(int)($tenant['id']??0);
            if($rid<1)throw new RuntimeException('Revenda inválida para esta operação.');
            return ['reseller',$rid];
        }
        throw new RuntimeException('Ambiente inválido para esta operação.');
    }

    public function whatsapp(array $tenant): array
    {
        if(!$this->tableExists('tenant_whatsapp_settings'))return ['phone'=>'','default_message'=>'','is_active'=>0];
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT phone,default_message,is_active FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);
        return $q->fetch()?:['phone'=>'','default_message'=>'','is_active'=>1];
    }

    public function saveWhatsapp(array $tenant,array $data): void
    {
        $this->requireTable('tenant_whatsapp_settings');
        [$scope,$rid]=$this->scope($tenant);
        $phone=preg_replace('/\D+/','',(string)($data['phone']??''));
        if($phone!==''&&(strlen($phone)<10||strlen($phone)>15))throw new RuntimeException('Informe o WhatsApp com DDD e código do país.');
        $message=trim((string)($data['default_message']??''));
        if(mb_strlen($message)>500)throw new RuntimeException('A mensagem padrão deve ter no máximo 500 caracteres.');
        $active=isset($data['is_active'])?1:0;
        $q=$this->pdo->prepare('SELECT id FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);$id=$q->fetchColumn();
        if($id){$u=$this->pdo->prepare('UPDATE tenant_whatsapp_settings SET phone=?,default_message=?,is_active=? WHERE id=?');$u->execute([$phone?:null,$message?:null,$active,$id]);return;}
        $u=$this->pdo->prepare('INSERT INTO tenant_whatsapp_settings(scope,reseller_id,phone,default_message,is_active) VALUES(?,?,?,?,?)');
        $u->execute([$scope,$rid,$phone?:null,$message?:null,$active]);
    }

    public function plans(array $tenant): array
    {
        if(!$this->tableExists('tenant_plans'))return [];
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT * FROM tenant_plans WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) ORDER BY sort_order,id');
        $q->execute([$scope,$rid,$rid]);return $q->fetchAll()?:[];
    }

    public function savePlan(array $tenant,array $data): void
    {
        $this->requireTable('tenant_plans');
        [$scope,$rid]=$this->scope($tenant);$id=(int)($data['id']??0);
        $name=trim((string)($data['name']??''));if($name===''||mb_strlen($name)>150)throw new RuntimeException('Informe um nome de plano com até 150 caracteres.');
        $priceRaw=trim((string)($data['price']??''));
        if($priceRaw===''){$price=null;}else{
            $normalized=str_replace(['R$',' '],'',$priceRaw);
            if(str_contains($normalized,',')&&str_contains($normalized,'.'))$normalized=str_replace('.','',$normalized);
            $normalized=str_replace(',','.',$normalized);
            if(!is_numeric($normalized)||(float)$normalized<0)throw new RuntimeException('Informe um preço válido.');
            $price=round((float)$normalized,2);
        }
        $period=trim((string)($data['period_label']??''));$desc=trim((string)($data['description']??''));
        $button=trim((string)($data['button_label']??''));$sort=(int)($data['sort_order']??0);
        if(mb_strlen($period)>80)throw new RuntimeException('O período deve ter no máximo 80 caracteres.');
        if(mb_strlen($button)>100)throw new RuntimeException('O texto do botão deve ter no máximo 100 caracteres.');
        $status=isset($data['status'])?'active':'inactive';
        $lines=preg_split('/\R/',(string)($data['benefits']??''))?:[];
        $benefits=array_values(array_filter(array_map('trim',$lines),static fn($v)=>$v!==''));
        if(count($benefits)>30)throw new RuntimeException('Informe no máximo 30 benefícios por plano.');
        foreach($benefits as $benefit)if(mb_strlen($benefit)>180)throw new RuntimeException('Cada benefício deve ter no máximo 180 caracteres.');
        $json=json_encode($benefits,JSON_UNESCAPED_UNICODE);
        if($json===false)throw new RuntimeException('Não foi possível processar os benefícios do plano.');
        if($id){
            $check=$this->pdo->prepare('SELECT id FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
            $check->execute([$id,$scope,$rid,$rid]);
            if(!$check->fetchColumn())throw new RuntimeException('Plano não encontrado neste site.');
            $q=$this->pdo->prepare('UPDATE tenant_plans SET name=?,price=?,period_label=?,description=?,benefits=?,button_label=?,sort_order=?,status=? WHERE id=?');
            $q->execute([$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status,$id]);return;
        }
        $q=$this->pdo->prepare('INSERT INTO tenant_plans(scope,reseller_id,name,price,period_label,description,benefits,button_label,sort_order,status) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $q->execute([$scope,$rid,$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status]);
    }

    public function deletePlan(array $tenant,int $id): void
    {
        $this->requireTable('tenant_plans');
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('DELETE FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?)');
        $q->execute([$id,$scope,$rid,$rid]);
        if($q->rowCount()===0){
            $check=$this->pdo->prepare('SELECT id FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
            $check->execute([$id,$scope,$rid,$rid]);
            if(!$check->fetchColumn())throw new RuntimeException('Plano não encontrado neste site.');
        }
    }

    public function sportsApiSettings(): array
    {
        if(!$this->tableExists('sports_api_settings'))return [];
        $rows=$this->pdo->query("SELECT sport,api_url,tomorrow_url,is_active FROM sports_api_settings ORDER BY FIELD(sport,'football','basketball','ufc')")->fetchAll();
        $by=[];foreach($rows?:[] as $row)$by[(string)$row['sport']]=$row;
        foreach(['football','basketball','ufc'] as $sport)if(!isset($by[$sport]))$by[$sport]=['sport'=>$sport,'api_url'=>'','tomorrow_url'=>'','is_active'=>0];
        return $by;
    }

    public function saveSportsApiSettings(array $data): void
    {
        $this->requireTable('sports_api_settings');
        foreach(['football','basketball','ufc'] as $sport){
            $url=trim((string)($data[$sport.'_url']??''));
            $tomorrow=$sport==='football'?trim((string)($data['football_tomorrow_url']??'')):'';
            $active=isset($data[$sport.'_active'])?1:0;
            if($url!==''&&!$this->validApiUrl($url))throw new RuntimeException('Informe uma URL HTTPS válida para '.ucfirst($sport).'.');
            if($tomorrow!==''&&!$this->validApiUrl($tomorrow))throw new RuntimeException('Informe uma URL HTTPS válida para Futebol amanhã.');
            if($active&&$url==='')throw new RuntimeException('Informe a URL antes de ativar '.ucfirst($sport).'.');
            $q=$this->pdo->prepare('INSERT INTO sports_api_settings(sport,api_url,tomorrow_url,is_active) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE api_url=VALUES(api_url),tomorrow_url=VALUES(tomorrow_url),is_active=VALUES(is_active)');
            $q->execute([$sport,$url,$tomorrow?:null,$active]);
        }
    }

    private function validApiUrl(string $url): bool
    {
        if(!filter_var($url,FILTER_VALIDATE_URL))return false;
        $p=parse_url($url);if(($p['scheme']??'')!=='https'||empty($p['host']))return false;
        $host=mb_strtolower((string)$p['host']);
        return $host!=='localhost'&&!filter_var($host,FILTER_VALIDATE_IP);
    }


    private function tableExists(string $table): bool
    {
        $q=$this->pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
        $q->execute([$table]);
        return (int)$q->fetchColumn()>0;
    }

    private function requireTable(string $table): void
    {
        if(!$this->tableExists($table))throw new RuntimeException('Este módulo precisa da atualização atual do banco de dados. Acesse Backup e atualize o banco antes de salvar.');
    }
}

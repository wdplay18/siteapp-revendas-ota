<?php

declare(strict_types=1);

namespace SiteApp\Services;

use PDO;

final class SportsGuideService
{
    public function __construct(private PDO $pdo) {}

    public function feed(string $day='today'): array
    {
        $day=$day==='tomorrow'?'tomorrow':'today';
        $settings=$this->settings();
        $items=[];$errors=[];
        foreach($settings as $setting){
            if((int)$setting['is_active']!==1)continue;
            $sport=(string)$setting['sport'];
            try{
                $separateTomorrow=$day==='tomorrow'&&$sport==='football'&&trim((string)($setting['tomorrow_url']??''))!=='';
                $url=$separateTomorrow?(string)$setting['tomorrow_url']:(string)$setting['api_url'];
                $payload=$this->unwrapPayload($this->fetchJson($url));
                $normalized=$sport==='ufc'?$this->normalizeUfc($payload,$day):$this->normalizeMatches($payload,$sport,$day,$separateTomorrow);
                $items=array_merge($items,$normalized);
            }catch(\Throwable $e){$errors[$sport]=$e->getMessage();}
        }
        usort($items,static fn(array$a,array$b):int=>strcmp((string)($a['time']??'99:99'),(string)($b['time']??'99:99')));
        return ['items'=>$items,'errors'=>$errors,'enabled_sports'=>array_values(array_map(static fn($r)=>(string)$r['sport'],array_filter($settings,static fn($r)=>(int)$r['is_active']===1)))];
    }

    public function settings(): array
    {
        if(!$this->tableExists('sports_api_settings'))return [];
        $rows=$this->pdo->query("SELECT sport,api_url,tomorrow_url,is_active FROM sports_api_settings ORDER BY FIELD(sport,'football','basketball','ufc')")->fetchAll();
        return $rows?:[];
    }

    private function unwrapPayload(array $payload): array
    {
        if(isset($payload['status'])&&isset($payload['data'])&&is_array($payload['data']))return $payload['data'];
        if(isset($payload['matches'])&&is_array($payload['matches']))return $payload['matches'];
        if(isset($payload['events'])&&is_array($payload['events']))return $payload['events'];
        return array_is_list($payload)?$payload:[];
    }

    private function normalizeMatches(array $payload,string $sport,string $day,bool $separateTomorrow=false): array
    {
        $out=[];
        foreach($payload as $row){
            if(!is_array($row))continue;
            $rawDay=mb_strtolower(trim((string)($row['data_jogo']??$row['data']??'')));
            if($sport==='football'){
                if($day==='today'&&!in_array($rawDay,['hoje','today',''],true))continue;
                if($day==='tomorrow'&&!$separateTomorrow&&!in_array($rawDay,['amanha','amanhã','tomorrow'],true))continue;
            }elseif($day==='tomorrow'){continue;}
            $channels=[];
            foreach(($row['canais']??[]) as $channel)if(is_array($channel))$channels[]=['name'=>(string)($channel['nome']??$channel['name']??''),'logo'=>(string)($channel['img_url']??$channel['logo']??'')];
            if(!$channels&&!empty($row['canal']))$channels[]=['name'=>(string)$row['canal'],'logo'=>(string)($row['img_canal_url']??'')];
            $status=trim((string)($row['status']??''));
            $state=$this->matchState($status);
            $out[]=['sport'=>$sport,'kind'=>'match','competition'=>(string)($row['competicao']??$row['campeonato']??''),'competition_logo'=>(string)($row['img_competicao_url']??''),'time'=>(string)($row['horario']??$row['tempo']??''),'status'=>$status,'state'=>$state,'home'=>(string)($row['time1']??$row['time_casa']??''),'away'=>(string)($row['time2']??$row['time_fora']??''),'home_logo'=>(string)($row['img_time1_url']??''),'away_logo'=>(string)($row['img_time2_url']??''),'home_score'=>(string)($row['placar_time1']??$row['placar_casa']??''),'away_score'=>(string)($row['placar_time2']??$row['placar_fora']??''),'channels'=>$channels];
        }
        return $out;
    }

    private function normalizeUfc(array $payload,string $day): array
    {
        $tz=new \DateTimeZone('America/Sao_Paulo');$target=(new \DateTimeImmutable($day==='tomorrow'?'tomorrow':'today',$tz))->format('d/m/Y');
        $out=[];
        foreach($payload as $event){
            if(!is_array($event))continue;
            $dateTime=trim((string)($event['data_evento']??''));
            if($dateTime===''||!str_starts_with($dateTime,$target))continue;
            $time=trim((string)(explode(',',$dateTime,2)[1]??''));
            foreach(['card_principal','preliminares'] as $section){
                foreach(($event[$section]??[]) as $fight){
                    if(!is_array($fight))continue;$fighters=$fight['lutadores']??[];
                    if(!is_array($fighters)||count($fighters)<2)continue;
                    $out[]=['sport'=>'ufc','kind'=>'fight','competition'=>(string)($event['evento']??'UFC'),'competition_logo'=>'','time'=>$time,'status'=>(string)($fight['tipo_evento']??''),'state'=>'scheduled','home'=>(string)($fighters[0]['nome_lutador']??''),'away'=>(string)($fighters[1]['nome_lutador']??''),'home_logo'=>(string)($fighters[0]['url_imagem']??''),'away_logo'=>(string)($fighters[1]['url_imagem']??''),'home_flag'=>(string)($fighters[0]['url_bandeira']??''),'away_flag'=>(string)($fighters[1]['url_bandeira']??''),'home_score'=>'','away_score'=>'','category'=>(string)($fight['categoria']??''),'venue'=>(string)($event['local_evento']??''),'channels'=>[['name'=>(string)($event['canal_transmissao']??''),'logo'=>(string)($event['logo_canal']??'')]]];
                }
            }
        }
        return $out;
    }

    private function matchState(string $status): string
    {
        $s=mb_strtoupper(trim($status));
        if($s==='')return 'scheduled';
        if(str_contains($s,'FIM')||str_contains($s,'ENCERR')||str_contains($s,'FINALIZ'))return 'finished';
        return 'live';
    }

    private function fetchJson(string $url): array
    {
        if(!$this->validRemoteUrl($url))throw new \RuntimeException('URL da API inválida.');
        $this->assertPublicHost((string)parse_url($url,PHP_URL_HOST));
        $cacheDir=dirname(__DIR__,2).'/storage/tmp/sports-api-cache';
        $cacheFile=$cacheDir.'/'.hash('sha256',$url).'.json';
        if(is_file($cacheFile)&&time()-(int)filemtime($cacheFile)<60){
            $cached=$this->readCache($cacheFile);
            if($cached!==null)return $cached;
        }
        $context=stream_context_create(['http'=>['timeout'=>8,'follow_location'=>0,'user_agent'=>'SiteApp-Revendas/1.0','header'=>"Accept: application/json\r\n"],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $raw=@file_get_contents($url,false,$context);
        if($raw!==false&&strlen($raw)<=5*1024*1024){
            try{
                $data=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
                if(is_array($data)){
                    $this->writeCache($cacheDir,$cacheFile,$raw);
                    return $data;
                }
            }catch(\JsonException){}
        }
        if(is_file($cacheFile)&&time()-(int)filemtime($cacheFile)<1800){
            $stale=$this->readCache($cacheFile);
            if($stale!==null)return $stale;
        }
        if($raw!==false&&strlen($raw)>5*1024*1024)throw new \RuntimeException('Resposta da API excedeu o limite permitido.');
        if($raw!==false)throw new \RuntimeException('Resposta JSON inválida.');
        throw new \RuntimeException('Não foi possível consultar a API.');
    }

    private function readCache(string $cacheFile): ?array
    {
        $raw=@file_get_contents($cacheFile);
        if(!is_string($raw)||$raw==='')return null;
        try{$data=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}
        catch(\JsonException){@unlink($cacheFile);return null;}
        if(!is_array($data)){@unlink($cacheFile);return null;}
        return $data;
    }

    private function writeCache(string $cacheDir,string $cacheFile,string $raw): void
    {
        if(!(is_dir($cacheDir)||@mkdir($cacheDir,0775,true))||!is_writable($cacheDir))return;
        $tmp=@tempnam($cacheDir,'sports-');
        if($tmp===false)return;
        if(@file_put_contents($tmp,$raw,LOCK_EX)===false){@unlink($tmp);return;}
        if(!@rename($tmp,$cacheFile))@unlink($tmp);
    }

    private function validRemoteUrl(string $url): bool
    {
        if(!filter_var($url,FILTER_VALIDATE_URL))return false;
        $p=parse_url($url);if(($p['scheme']??'')!=='https'||empty($p['host']))return false;
        $host=mb_strtolower((string)$p['host']);
        if($host==='localhost'||filter_var($host,FILTER_VALIDATE_IP))return false;
        return true;
    }

    private function assertPublicHost(string $host): void
    {
        $records=@dns_get_record($host,DNS_A|DNS_AAAA);
        if(!is_array($records)||$records===[])throw new \RuntimeException('Não foi possível resolver o host da API.');
        foreach($records as $record){
            $ip=(string)($record['ip']??$record['ipv6']??'');
            if($ip===''||filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)===false)throw new \RuntimeException('O host da API não pode apontar para uma rede privada ou reservada.');
        }
    }

    private function tableExists(string $table): bool
    {
        $q=$this->pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');$q->execute([$table]);return(int)$q->fetchColumn()>0;
    }
}

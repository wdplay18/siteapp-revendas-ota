<?php
$commercialAdmin=new \SiteApp\Services\CommercialAdminService($pdo);
$apiSettings=$commercialAdmin->sportsApiSettings();
$e=fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
$labels=['football'=>'Futebol','basketball'=>'Basquete','ufc'=>'UFC'];
?>
<?php if(!$isMaster):?>
<section class="admin-card"><div class="admin-card__head"><div><span class="card-kicker">GUIA DE JOGOS</span><h2>Programação automática</h2><p>O Guia de Jogos é alimentado pelas APIs configuradas pelo Master e exibido automaticamente nesta Revenda.</p></div></div><div class="admin-section"><p class="muted">A Revenda não cadastra partidas nem precisa configurar as fontes esportivas.</p></div></section>
<?php else:?>
<section class="admin-card"><div class="admin-card__head"><div><span class="card-kicker">GUIA DE JOGOS</span><h2>Fontes esportivas</h2><p>Configure as URLs JSON usadas para montar automaticamente Futebol, Basquete e UFC. As consultas são feitas pelo servidor.</p></div></div>
<?php if(!$apiSettings):?><div class="admin-section"><p class="muted">Este módulo precisa da atualização V9 do banco antes de salvar as APIs.</p></div><?php endif;?>
<form class="admin-form" method="post" action="/commercial-action.php"><input type="hidden" name="csrf_token" value="<?=$e($csrfToken)?>"><input type="hidden" name="action" value="save_sports_apis">
<?php foreach($labels as $sport=>$label):$row=$apiSettings[$sport]??['api_url'=>'','is_active'=>0];?>
<div class="admin-section"><label><strong><?=$e($label)?></strong><input type="url" name="<?=$e($sport)?>_url" maxlength="1000" placeholder="https://...json" value="<?=$e($row['api_url']??'')?>"></label><label class="check-row"><input type="checkbox" name="<?=$e($sport)?>_active" value="1" <?=(int)($row['is_active']??0)===1?'checked':''?>> Exibir <?=$e($label)?> no Guia de Jogos</label></div>
<?php if($sport==='football'):?><label>Futebol — amanhã<input type="url" name="football_tomorrow_url" maxlength="1000" placeholder="https://...json" value="<?=$e($row['tomorrow_url']??'')?>"><small class="muted">Opcional. Use quando o provedor tiver um endpoint separado para os jogos de amanhã.</small></label><?php endif;?>
<?php endforeach;?>
<div class="commercial-save-bar"><p>O token permanece no servidor e não é colocado no HTML público.</p><button class="btn btn-primary" <?=!$apiSettings?'disabled aria-disabled="true" title="Atualize o banco para V9 antes de salvar"':''?>>Salvar APIs</button></div></form></section>
<section class="admin-card"><div class="admin-card__head"><div><h2>Como funciona</h2><p>Não existe mais cadastro manual de partidas.</p></div></div><div class="admin-section"><p class="muted">Futebol e Basquete usam o formato de partidas da TropaTech. UFC usa o formato de evento, card principal, preliminares e lutadores. Uma modalidade desativada deixa de aparecer no site público.</p></div></section>
<?php endif;?>
(function () {
  'use strict';

  function initPublicMenus() {
    document.querySelectorAll('.mobile-menu-toggle').forEach(function (button) {
      var menuId = button.getAttribute('aria-controls');
      var menu = menuId ? document.getElementById(menuId) : null;
      if (!menu || button.dataset.menuReady === 'true') return;

      button.dataset.menuReady = 'true';

      function setOpen(open) {
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
        button.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
        menu.classList.toggle('open', open);
      }

      button.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        setOpen(button.getAttribute('aria-expanded') !== 'true');
      });

      menu.addEventListener('click', function (event) {
        event.stopPropagation();
        if (event.target.closest('a')) setOpen(false);
      });

      document.addEventListener('click', function (event) {
        if (!menu.contains(event.target) && !button.contains(event.target)) setOpen(false);
      });

      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') setOpen(false);
      });

      window.addEventListener('resize', function () {
        if (window.innerWidth > 700) setOpen(false);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPublicMenus);
  } else {
    initPublicMenus();
  }
}());


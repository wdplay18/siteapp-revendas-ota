<?php

declare(strict_types=1);

namespace SiteApp\Services;

use PDO;
use RuntimeException;

final class CommercialAdminService
{
    public function __construct(private PDO $pdo) {}

    private function scope(array $tenant): array
    {
        $scope=($tenant['type']??'')==='reseller'?'reseller':'master';
        return [$scope,$scope==='reseller'?(int)($tenant['id']??0):null];
    }

    public function whatsapp(array $tenant): array
    {
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT phone,default_message,is_active FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);
        return $q->fetch()?:['phone'=>'','default_message'=>'','is_active'=>1];
    }

    public function saveWhatsapp(array $tenant,array $data): void
    {
        [$scope,$rid]=$this->scope($tenant);
        $phone=preg_replace('/\D+/','',(string)($data['phone']??''));
        if($phone!==''&&(strlen($phone)<10||strlen($phone)>15))throw new RuntimeException('Informe o WhatsApp com DDD e código do país.');
        $message=trim((string)($data['default_message']??''));
        if(mb_strlen($message)>500)throw new RuntimeException('A mensagem padrão deve ter no máximo 500 caracteres.');
        $active=isset($data['is_active'])?1:0;
        $q=$this->pdo->prepare('SELECT id FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);$id=$q->fetchColumn();
        if($id){$u=$this->pdo->prepare('UPDATE tenant_whatsapp_settings SET phone=?,default_message=?,is_active=? WHERE id=?');$u->execute([$phone?:null,$message?:null,$active,$id]);return;}
        $u=$this->pdo->prepare('INSERT INTO tenant_whatsapp_settings(scope,reseller_id,phone,default_message,is_active) VALUES(?,?,?,?,?)');
        $u->execute([$scope,$rid,$phone?:null,$message?:null,$active]);
    }

    public function plans(array $tenant): array
    {
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT * FROM tenant_plans WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) ORDER BY sort_order,id');
        $q->execute([$scope,$rid,$rid]);return $q->fetchAll()?:[];
    }

    public function savePlan(array $tenant,array $data): void
    {
        [$scope,$rid]=$this->scope($tenant);$id=(int)($data['id']??0);
        $name=trim((string)($data['name']??''));if($name==='')throw new RuntimeException('Informe o nome do plano.');
        $priceRaw=trim((string)($data['price']??''));
        if($priceRaw===''){$price=null;}else{
            $normalized=str_replace(['R$',' '],'',$priceRaw);
            if(str_contains($normalized,',')&&str_contains($normalized,'.'))$normalized=str_replace('.','',$normalized);
            $normalized=str_replace(',','.',$normalized);
            if(!is_numeric($normalized)||(float)$normalized<0)throw new RuntimeException('Informe um preço válido.');
            $price=round((float)$normalized,2);
        }
        $period=trim((string)($data['period_label']??''));$desc=trim((string)($data['description']??''));
        $button=trim((string)($data['button_label']??''));$sort=(int)($data['sort_order']??0);
        $status=isset($data['status'])?'active':'inactive';
        $lines=preg_split('/\R/',(string)($data['benefits']??''))?:[];
        $benefits=array_values(array_filter(array_map('trim',$lines),static fn($v)=>$v!==''));
        $json=json_encode($benefits,JSON_UNESCAPED_UNICODE);
        if($id){
            $check=$this->pdo->prepare('SELECT id FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
            $check->execute([$id,$scope,$rid,$rid]);
            if(!$check->fetchColumn())throw new RuntimeException('Plano não encontrado neste site.');
            $q=$this->pdo->prepare('UPDATE tenant_plans SET name=?,price=?,period_label=?,description=?,benefits=?,button_label=?,sort_order=?,status=? WHERE id=?');
            $q->execute([$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status,$id]);return;
        }
        $q=$this->pdo->prepare('INSERT INTO tenant_plans(scope,reseller_id,name,price,period_label,description,benefits,button_label,sort_order,status) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $q->execute([$scope,$rid,$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status]);
    }

    public function deletePlan(array $tenant,int $id): void
    {
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('DELETE FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?)');
        $q->execute([$id,$scope,$rid,$rid]);
    }

    public function games(): array
    {
        return $this->pdo->query("SELECT * FROM game_guide_entries WHERE event_date>=DATE_SUB(CURDATE(),INTERVAL 1 DAY) ORDER BY event_date,event_time,sort_order,id LIMIT 250")->fetchAll()?:[];
    }

    public function saveGame(array $data): void
    {
        $id=(int)($data['id']??0);$title=trim((string)($data['title']??''));$date=trim((string)($data['event_date']??''));
        if($title===''||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))throw new RuntimeException('Informe título e data válidos.');
        $time=trim((string)($data['event_time']??''));$competition=trim((string)($data['competition']??''));
        $channel=trim((string)($data['channel']??''));$notes=trim((string)($data['notes']??''));
        $sort=(int)($data['sort_order']??0);$status=isset($data['status'])?'active':'inactive';
        if($id){$q=$this->pdo->prepare('UPDATE game_guide_entries SET title=?,competition=?,event_date=?,event_time=?,channel=?,notes=?,sort_order=?,status=? WHERE id=?');$q->execute([$title,$competition?:null,$date,$time?:null,$channel?:null,$notes?:null,$sort,$status,$id]);return;}
        $q=$this->pdo->prepare('INSERT INTO game_guide_entries(title,competition,event_date,event_time,channel,notes,sort_order,status) VALUES(?,?,?,?,?,?,?,?)');
        $q->execute([$title,$competition?:null,$date,$time?:null,$channel?:null,$notes?:null,$sort,$status]);
    }

    public function deleteGame(int $id): void
    {
        $q=$this->pdo->prepare('DELETE FROM game_guide_entries WHERE id=?');$q->execute([$id]);
    }
}

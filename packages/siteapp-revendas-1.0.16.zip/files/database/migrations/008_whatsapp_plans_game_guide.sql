-- Migration 008: módulos comerciais públicos e administrativos
CREATE TABLE IF NOT EXISTS tenant_whatsapp_settings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, scope ENUM('master','reseller') NOT NULL, reseller_id BIGINT UNSIGNED NULL,
 phone VARCHAR(32) NULL, default_message VARCHAR(500) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_whatsapp_reseller(reseller_id), CONSTRAINT fk_whatsapp_reseller FOREIGN KEY(reseller_id) REFERENCES resellers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tenant_plans (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, scope ENUM('master','reseller') NOT NULL, reseller_id BIGINT UNSIGNED NULL,
 name VARCHAR(150) NOT NULL, price DECIMAL(10,2) NULL, period_label VARCHAR(80) NULL, description TEXT NULL, benefits JSON NULL,
 button_label VARCHAR(100) NULL, sort_order INT NOT NULL DEFAULT 0, status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_tenant_plans_scope(scope,reseller_id,status,sort_order), CONSTRAINT fk_tenant_plans_reseller FOREIGN KEY(reseller_id) REFERENCES resellers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS game_guide_entries (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(180) NOT NULL, competition VARCHAR(150) NULL, event_date DATE NOT NULL,
 event_time TIME NULL, channel VARCHAR(150) NULL, notes VARCHAR(500) NULL, sort_order INT NOT NULL DEFAULT 0,
 status ENUM('active','inactive') NOT NULL DEFAULT 'active', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, KEY idx_game_guide_date(event_date,status,sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
<?php
declare(strict_types=1);
use SiteApp\Core\Csrf;use SiteApp\Services\CommercialAdminService;
$app=require __DIR__.'/bootstrap.php';$tenant=$app['tenantResolver']->resolve($_SERVER['HTTP_HOST']??'');if(($tenant['type']??'unknown')==='unknown'){http_response_code(404);exit('Site não encontrado.');}
if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){header('Location: /admin',true,302);exit;}
$tab='site';
try{$auth=$app['auth'];if(!$auth->check()){header('Location: /admin/login',true,302);exit;}if(($tenant['type']??'')==='master')$auth->requireMaster($tenant);else$auth->requireReseller($tenant);Csrf::validate($_POST['csrf_token']??null);$svc=new CommercialAdminService($app['database']->pdo());$action=(string)($_POST['action']??'');
if($action==='save_whatsapp'){$tab='atendimento';$svc->saveWhatsapp($tenant,$_POST);$_SESSION['flash_success']='WhatsApp salvo com sucesso.';}
elseif($action==='save_plan'){$tab='plans';$svc->savePlan($tenant,$_POST);$_SESSION['flash_success']='Plano salvo com sucesso.';}
elseif($action==='delete_plan'){$tab='plans';if(trim((string)($_POST['delete_confirmation']??''))!=='EXCLUIR')throw new RuntimeException('Confirme a exclusão digitando EXCLUIR.');$svc->deletePlan($tenant,(int)($_POST['id']??0));$_SESSION['flash_success']='Plano excluído.';}
elseif($action==='save_game'){$tab='games';if(($tenant['type']??'')!=='master')throw new RuntimeException('O Guia de Jogos é administrado pelo Master.');$svc->saveGame($_POST);$_SESSION['flash_success']='Jogo salvo com sucesso.';}
elseif($action==='delete_game'){$tab='games';if(($tenant['type']??'')!=='master')throw new RuntimeException('O Guia de Jogos é administrado pelo Master.');if(trim((string)($_POST['delete_confirmation']??''))!=='EXCLUIR')throw new RuntimeException('Confirme a exclusão digitando EXCLUIR.');$svc->deleteGame((int)($_POST['id']??0));$_SESSION['flash_success']='Jogo excluído.';}
else throw new RuntimeException('Ação inválida.');
}catch(Throwable $e){$_SESSION['flash_error']=$e->getMessage();}
header('Location: /admin?tab='.$tab,true,302);exit;
<?php

declare(strict_types=1);

namespace SiteApp\Services;

use PDO;
use RuntimeException;

final class CommercialAdminService
{
    public function __construct(private PDO $pdo) {}

    private function scope(array $tenant): array
    {
        $type=(string)($tenant['type']??'');
        if($type==='master')return ['master',null];
        if($type==='reseller'){
            $rid=(int)($tenant['id']??0);
            if($rid<1)throw new RuntimeException('Revenda inválida para esta operação.');
            return ['reseller',$rid];
        }
        throw new RuntimeException('Ambiente inválido para esta operação.');
    }

    public function whatsapp(array $tenant): array
    {
        if(!$this->tableExists('tenant_whatsapp_settings'))return ['phone'=>'','default_message'=>'','is_active'=>0];
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT phone,default_message,is_active FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);
        return $q->fetch()?:['phone'=>'','default_message'=>'','is_active'=>1];
    }

    public function saveWhatsapp(array $tenant,array $data): void
    {
        $this->requireTable('tenant_whatsapp_settings');
        [$scope,$rid]=$this->scope($tenant);
        $phone=preg_replace('/\D+/','',(string)($data['phone']??''));
        if($phone!==''&&(strlen($phone)<10||strlen($phone)>15))throw new RuntimeException('Informe o WhatsApp com DDD e código do país.');
        $message=trim((string)($data['default_message']??''));
        if(mb_strlen($message)>500)throw new RuntimeException('A mensagem padrão deve ter no máximo 500 caracteres.');
        $active=isset($data['is_active'])?1:0;
        $q=$this->pdo->prepare('SELECT id FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
        $q->execute([$scope,$rid,$rid]);$id=$q->fetchColumn();
        if($id){$u=$this->pdo->prepare('UPDATE tenant_whatsapp_settings SET phone=?,default_message=?,is_active=? WHERE id=?');$u->execute([$phone?:null,$message?:null,$active,$id]);return;}
        $u=$this->pdo->prepare('INSERT INTO tenant_whatsapp_settings(scope,reseller_id,phone,default_message,is_active) VALUES(?,?,?,?,?)');
        $u->execute([$scope,$rid,$phone?:null,$message?:null,$active]);
    }

    public function plans(array $tenant): array
    {
        if(!$this->tableExists('tenant_plans'))return [];
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('SELECT * FROM tenant_plans WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) ORDER BY sort_order,id');
        $q->execute([$scope,$rid,$rid]);return $q->fetchAll()?:[];
    }

    public function savePlan(array $tenant,array $data): void
    {
        $this->requireTable('tenant_plans');
        [$scope,$rid]=$this->scope($tenant);$id=(int)($data['id']??0);
        $name=trim((string)($data['name']??''));if($name===''||mb_strlen($name)>150)throw new RuntimeException('Informe um nome de plano com até 150 caracteres.');
        $priceRaw=trim((string)($data['price']??''));
        if($priceRaw===''){$price=null;}else{
            $normalized=str_replace(['R$',' '],'',$priceRaw);
            if(str_contains($normalized,',')&&str_contains($normalized,'.'))$normalized=str_replace('.','',$normalized);
            $normalized=str_replace(',','.',$normalized);
            if(!is_numeric($normalized)||(float)$normalized<0)throw new RuntimeException('Informe um preço válido.');
            $price=round((float)$normalized,2);
        }
        $period=trim((string)($data['period_label']??''));$desc=trim((string)($data['description']??''));
        $button=trim((string)($data['button_label']??''));$sort=(int)($data['sort_order']??0);
        if(mb_strlen($period)>80)throw new RuntimeException('O período deve ter no máximo 80 caracteres.');
        if(mb_strlen($button)>100)throw new RuntimeException('O texto do botão deve ter no máximo 100 caracteres.');
        $status=isset($data['status'])?'active':'inactive';
        $lines=preg_split('/\R/',(string)($data['benefits']??''))?:[];
        $benefits=array_values(array_filter(array_map('trim',$lines),static fn($v)=>$v!==''));
        if(count($benefits)>30)throw new RuntimeException('Informe no máximo 30 benefícios por plano.');
        foreach($benefits as $benefit)if(mb_strlen($benefit)>180)throw new RuntimeException('Cada benefício deve ter no máximo 180 caracteres.');
        $json=json_encode($benefits,JSON_UNESCAPED_UNICODE);
        if($json===false)throw new RuntimeException('Não foi possível processar os benefícios do plano.');
        if($id){
            $check=$this->pdo->prepare('SELECT id FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
            $check->execute([$id,$scope,$rid,$rid]);
            if(!$check->fetchColumn())throw new RuntimeException('Plano não encontrado neste site.');
            $q=$this->pdo->prepare('UPDATE tenant_plans SET name=?,price=?,period_label=?,description=?,benefits=?,button_label=?,sort_order=?,status=? WHERE id=?');
            $q->execute([$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status,$id]);return;
        }
        $q=$this->pdo->prepare('INSERT INTO tenant_plans(scope,reseller_id,name,price,period_label,description,benefits,button_label,sort_order,status) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $q->execute([$scope,$rid,$name,$price,$period?:null,$desc?:null,$json,$button?:null,$sort,$status]);
    }

    public function deletePlan(array $tenant,int $id): void
    {
        $this->requireTable('tenant_plans');
        [$scope,$rid]=$this->scope($tenant);
        $q=$this->pdo->prepare('DELETE FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?)');
        $q->execute([$id,$scope,$rid,$rid]);
        if($q->rowCount()===0){
            $check=$this->pdo->prepare('SELECT id FROM tenant_plans WHERE id=? AND scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) LIMIT 1');
            $check->execute([$id,$scope,$rid,$rid]);
            if(!$check->fetchColumn())throw new RuntimeException('Plano não encontrado neste site.');
        }
    }

    public function games(): array
    {
        if(!$this->tableExists('game_guide_entries'))return [];
        return $this->pdo->query("SELECT * FROM game_guide_entries WHERE event_date>=DATE_SUB(CURDATE(),INTERVAL 1 DAY) ORDER BY event_date,sort_order,event_time,id LIMIT 250")->fetchAll()?:[];
    }

    public function saveGame(array $data): void
    {
        $this->requireTable('game_guide_entries');
        $id=(int)($data['id']??0);$title=trim((string)($data['title']??''));$date=trim((string)($data['event_date']??''));
        if($title===''||mb_strlen($title)>180)throw new RuntimeException('Informe um jogo / evento com até 180 caracteres.');
        if(!$this->validDate($date))throw new RuntimeException('Informe uma data válida.');
        $time=trim((string)($data['event_time']??''));$competition=trim((string)($data['competition']??''));
        $channel=trim((string)($data['channel']??''));$notes=trim((string)($data['notes']??''));
        if($time!==''&&!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/',$time))throw new RuntimeException('Informe um horário válido.');
        if(mb_strlen($competition)>150||mb_strlen($channel)>150||mb_strlen($notes)>500)throw new RuntimeException('Um dos campos do jogo ultrapassa o limite permitido.');
        $sort=(int)($data['sort_order']??0);$status=isset($data['status'])?'active':'inactive';
        if($id){
            $check=$this->pdo->prepare('SELECT id FROM game_guide_entries WHERE id=? LIMIT 1');$check->execute([$id]);
            if(!$check->fetchColumn())throw new RuntimeException('Jogo não encontrado.');
            $q=$this->pdo->prepare('UPDATE game_guide_entries SET title=?,competition=?,event_date=?,event_time=?,channel=?,notes=?,sort_order=?,status=? WHERE id=?');$q->execute([$title,$competition?:null,$date,$time?:null,$channel?:null,$notes?:null,$sort,$status,$id]);return;
        }
        $q=$this->pdo->prepare('INSERT INTO game_guide_entries(title,competition,event_date,event_time,channel,notes,sort_order,status) VALUES(?,?,?,?,?,?,?,?)');
        $q->execute([$title,$competition?:null,$date,$time?:null,$channel?:null,$notes?:null,$sort,$status]);
    }

    public function deleteGame(int $id): void
    {
        $this->requireTable('game_guide_entries');
        if($id<1)throw new RuntimeException('Jogo inválido.');
        $q=$this->pdo->prepare('DELETE FROM game_guide_entries WHERE id=?');$q->execute([$id]);
        if($q->rowCount()!==1)throw new RuntimeException('Jogo não encontrado.');
    }
    private function validDate(string $date): bool
    {
        $parsed=\DateTimeImmutable::createFromFormat('!Y-m-d',$date);
        $errors=\DateTimeImmutable::getLastErrors();
        return $parsed!==false&&($errors===false||($errors['warning_count']===0&&$errors['error_count']===0))&&$parsed->format('Y-m-d')===$date;
    }

    private function tableExists(string $table): bool
    {
        $q=$this->pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
        $q->execute([$table]);
        return (int)$q->fetchColumn()>0;
    }

    private function requireTable(string $table): void
    {
        if(!$this->tableExists($table))throw new RuntimeException('Este módulo precisa da atualização V8 do banco de dados. Acesse Backup e atualize o banco antes de salvar.');
    }
}

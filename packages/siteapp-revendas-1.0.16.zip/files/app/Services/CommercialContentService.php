<?php

declare(strict_types=1);

namespace SiteApp\Services;

use PDO;

final class CommercialContentService
{
    public function __construct(private PDO $pdo) {}

    public function plans(array $tenant): array
    {
        if(!$this->tableExists('tenant_plans'))return [];
        $scope=($tenant['type']??'')==='reseller'?'reseller':'master';
        $resellerId=$scope==='reseller'?(int)($tenant['id']??0):null;
        $q=$this->pdo->prepare("SELECT id,name,price,period_label,description,benefits,button_label FROM tenant_plans WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) AND status='active' ORDER BY sort_order,id");
        $q->execute([$scope,$resellerId,$resellerId]);
        return $q->fetchAll() ?: [];
    }

    public function games(string $date): array
    {
        if(!$this->tableExists('game_guide_entries'))return [];
        $q=$this->pdo->prepare("SELECT id,title,competition,event_date,event_time,channel,notes FROM game_guide_entries WHERE event_date=? AND status='active' ORDER BY sort_order,event_time,id");
        $q->execute([$date]);
        return $q->fetchAll() ?: [];
    }

    public function whatsapp(array $tenant): ?array
    {
        if(!$this->tableExists('tenant_whatsapp_settings'))return null;
        $scope=($tenant['type']??'')==='reseller'?'reseller':'master';
        $resellerId=$scope==='reseller'?(int)($tenant['id']??0):null;
        $q=$this->pdo->prepare("SELECT phone,default_message FROM tenant_whatsapp_settings WHERE scope=? AND ((? IS NULL AND reseller_id IS NULL) OR reseller_id=?) AND is_active=1 LIMIT 1");
        $q->execute([$scope,$resellerId,$resellerId]);
        $row=$q->fetch();
        return $row?:null;
    }
}
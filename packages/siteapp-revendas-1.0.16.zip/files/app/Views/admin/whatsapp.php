<?php
$commercialAdmin=new \SiteApp\Services\CommercialAdminService($pdo);
$wa=$commercialAdmin->whatsapp($tenant);
$e=fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
$isReseller=($tenant['type']??'')==='reseller';
?>
<section class="admin-card commercial-settings-card">
 <div class="admin-card__head"><div><span class="card-kicker">ATENDIMENTO</span><h2>WhatsApp</h2><p>Configure o contato usado pelos botões públicos do site.</p></div></div>
 <form class="admin-form" method="post" action="/commercial-action.php">
  <input type="hidden" name="csrf_token" value="<?=$e($csrfToken)?>">
  <input type="hidden" name="action" value="save_whatsapp">
  <div class="admin-section">
   <h3>Contato público</h3>
   <p class="muted"><?=$isReseller?'Esta configuração pertence somente a esta Revenda e não altera o WhatsApp do Master.':'Esta configuração pertence ao site Master. Cada Revenda pode manter o próprio contato.'?></p>
   <div class="form-grid">
    <label>Número com país e DDD<input name="phone" inputmode="tel" maxlength="20" value="<?=$e($wa['phone']??'')?>" placeholder="5584999999999"><small>Use somente um número que receba mensagens no WhatsApp. O sistema remove espaços, parênteses e traços ao salvar.</small></label>
    <label>Mensagem padrão<textarea name="default_message" rows="4" maxlength="500" placeholder="Olá! Gostaria de saber mais."><?=$e($wa['default_message']??'')?></textarea><small>Essa mensagem é preenchida automaticamente quando o visitante abre o atendimento.</small></label>
   </div>
   <label class="check-row"><input type="checkbox" name="is_active" value="1" <?=!empty($wa['is_active'])?'checked':''?>> Ativar atendimento pelo WhatsApp</label>
  </div>
  <div class="commercial-save-bar"><span class="muted">As alterações passam a valer nos botões públicos deste site.</span><button class="btn btn-primary" type="submit">Salvar WhatsApp</button></div>
 </form>
</section>